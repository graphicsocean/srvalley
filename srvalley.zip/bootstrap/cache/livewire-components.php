<?php return array (
  'frontend.amenities' => 'App\\Http\\Livewire\\Frontend\\Amenities',
  'frontend.breadcrumb' => 'App\\Http\\Livewire\\Frontend\\Breadcrumb',
  'frontend.explore-banquate' => 'App\\Http\\Livewire\\Frontend\\ExploreBanquate',
  'frontend.footer' => 'App\\Http\\Livewire\\Frontend\\Footer',
  'frontend.header' => 'App\\Http\\Livewire\\Frontend\\Header',
  'frontend.services' => 'App\\Http\\Livewire\\Frontend\\Services',
);