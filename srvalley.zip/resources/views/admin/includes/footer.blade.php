<div class="copyrights">
    <p>{{ date('Y') }} <i class="fa fa-copyright" aria-hidden="true"></i> SRvalley by <a href="#"
            target="_blank">TheBlockbusters</a></p>
</div>
