{{$sliders }}

{{-- @foreach ($collection as $item)

@endforeach --}}
