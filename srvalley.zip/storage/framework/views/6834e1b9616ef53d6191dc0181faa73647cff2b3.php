<?php $__env->startSection('content'); ?>
    <div class="dashboard-content">
        <div class="row">
            <!-- Listings -->
            <div class="col-lg-12 col-sm-12">
                <div id="add-listing">

                    <!-- Section -->
                    <form action="<?php echo e(url('admin/banners/'.$banner->id)); ?>" method="post"  enctype='multipart/form-data'>
                        <?php echo e(method_field('PUT')); ?>

                        <?php echo csrf_field(); ?>
                        <div class="add-listing-section">

                            <!-- Headline -->
                            <div class="add-listing-headline">
                                <h3><i class="sl sl-icon-doc"></i> Update Home Banner</h3>
                            </div>
                            <!-- Title -->
                            <div class="row with-forms">
                                <div class="col-md-6">
                                    <label>Main Title <i class="tip"
                                            data-tip-content="main title of banner"></i></label>
                                    <input name="title1" class="search-field" type="text" placeholder="type here..." value="<?php echo e($banner->title1); ?>" />
                                </div>
                                <div class="col-md-6">
                                    <label>Status </label>
                                        <select name="status" class="chosen-select-no-single">
                                            <option <?php echo e($banner->status == '1' ? 'Selected' : ''); ?> value="1">Active</option>
                                            <option <?php echo e($banner->status == '0' ? 'Selected' : ''); ?> value="0">Inactive</option>
                                        </select>
                                </div>
                            </div>

                            <!-- Row -->
                            <div class="row with-forms">

                                <!-- Status -->
                                <div class="col-md-6">
                                    <label>CTA<i class="tip"
                                            data-tip-content="Banner button text"></i></label>
                                    <input name="cta" class="search-field" type="text" placeholder="type here..." value="<?php echo e($banner->cta); ?>"/>
                                </div>

                                <!-- Type -->
                                <div class="col-md-6">
                                    <label>CTA link <i class="tip"
                                            data-tip-content="Banner button URL"></i></label>
                                    <input name="cta_link" type="text" value="<?php echo e($banner->cta_link); ?>">
                                </div>

                            </div>
                            <div class="row with-forms">

                                <!-- Status -->
                                <div class="col-md-6">
                                    <label>Sub Title <i class="tip"
                                            data-tip-content="Sub title will show before of banner main title"></i></label>
                                    <input name="title2" class="search-field" type="text" placeholder="type here..." value="<?php echo e($banner->title2); ?>"/>
                                </div>

                                <!-- Type -->
                                <div class="col-md-6">
                                    <label>Image <i class="tip"
                                            data-tip-content="Maximum of 2MB Allowed"></i></label>
                                    <input name="image" type="file">
                                </div>

                            </div>
                            <!-- Row / End -->


                        </div>
                        <!-- Section / End -->
                        <button class="button preview" type="submit">Submit <i
                                class="fa fa-arrow-circle-right"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\server\htdocs\srvalley\resources\views/admin/banner/edit.blade.php ENDPATH**/ ?>