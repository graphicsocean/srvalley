<?php $__env->startSection('title', 'Contact Us'); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.breadcrumb', ['title' => 'contact us'])->html();
} elseif ($_instance->childHasBeenRendered('KhZhmLA')) {
    $componentId = $_instance->getRenderedChildComponentId('KhZhmLA');
    $componentTag = $_instance->getRenderedChildComponentTagName('KhZhmLA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KhZhmLA');
} else {
    $response = \Livewire\Livewire::mount('frontend.breadcrumb', ['title' => 'contact us']);
    $html = $response->html();
    $_instance->logRenderedChild('KhZhmLA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- contact starts -->
    <?php
    $settings = App\Models\Setting::first();
    ?>
    <section class="contact">
        <div class="container">
            <div class="contact-info">
                <div class="row">
                    <div class="col-lg-4 col-md-12 mar-bottom-30">
                        <div class="info-item">
                            <div class="info-icon">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            <div class="info-content">
                                <p><?php echo e($settings->address); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mar-bottom-30">
                        <div class="info-item info-item-or">
                            <div class="info-icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="info-content">
                                <h4 style="color: white">+91-<?php echo e($settings->phone); ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mar-bottom-30">
                        <div class="info-item">
                            <div class="info-icon">
                                <i class="fa fa-envelope"></i>
                            </div>
                            <div class="info-content">
                                <h4 style="color: white">+91-<?php echo e($settings->email); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="contact-map">
                <div class="row">
                    <div class="col-lg-6">
                        <div id="map" style="height: 535px; width: 100%;">
                            <iframe width="100%" height="535"
                                src="https://maps.google.com/maps?q=SR%20Valley%20Wedding%20Venue%20&t=&z=13&ie=UTF8&iwloc=&output=embed"
                                frameborder="0" scrolling="yes" marginheight="0" marginwidth="0"></iframe>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div id="contact-form" class="contact-form">
                            <h3>Keep in Touch</h3>
                            <div id="contactform-error-msg"></div>

                            <form method="post" action="<?php echo e('submit-contact-form'); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input type="text" name="first_name" class="form-control" id="fname"
                                        placeholder="First Name" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="last_name" class="form-control" id="lname"
                                        placeholder="Last Name">
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control" id="email" placeholder="Email">
                                </div>
                                <div class="form-group">
                                    <input type="text" name="phone" class="form-control" id="phnumber" placeholder="Phone"
                                        required>
                                </div>
                                <div class="textarea">
                                    <textarea name="message" placeholder="Enter a message"></textarea>
                                </div>
                                <div class="comment-btn text-right">
                                    <button type="submit" class="btn btn-orange" id="submit">submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- contact Ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\server\htdocs\srvalley\resources\views/frontend/contact.blade.php ENDPATH**/ ?>