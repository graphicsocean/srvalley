<section class="breadcrumb-outer">
    <div class="container">
        <div class="breadcrumb-content">
            <h2><?php echo e($title); ?></h2>
            <nav aria-label="breadcrumb">
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($title); ?></li>
                </ul>
            </nav>
        </div>
    </div>
</section>


<?php /**PATH C:\server\htdocs\srvalley\resources\views/livewire/frontend/breadcrumb.blade.php ENDPATH**/ ?>