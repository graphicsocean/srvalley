<section class="rooms" id="banqets">
    <div class="container">
        <div class="section-title">
            <h2>Explore <span>banquate</span></h2>
            <p>Our Amazing <?php echo e(count($banquets)); ?> Banquets are:</p>
        </div>
        <div class="room-outer">
            <div class="row">
                <?php $__currentLoopData = $banquets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 mar-bottom-30">
                        <div class="room-item">
                            <div class="room-image">
                                <img src="<?php echo e(asset('ui/images/'.$item->thumbnail)); ?>" alt="image">
                            </div>
                            <div class="room-content">
                                <div class="room-title">
                                    <h4><?php echo e($item->name); ?></h4>
                                    <p><i class="fas fa-tag"></i> ₹ <?php echo e($item->price); ?></p>
                                    <div class="deal-rating">
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                    </div>
                                </div>
                                <div class="room-services mar-bottom-15">
                                    <?php echo html_entity_decode($item->special_features); ?>

                                </div>
                                <p><?php echo e($item->description); ?></p>
                                <div class="room-btns mar-top-20">
                                    <a href="<?php echo e(url('banquet/'.$item->slug)); ?>" class="btn btn-black mar-right-10">VIEW
                                        DETAILS</a>
                                    <a href="tel:8048072230" class="btn btn-orange">BOOK NOW</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
        
    </div>
</section>
<?php /**PATH C:\server\htdocs\srvalley\resources\views/livewire/frontend/explore-banquate.blade.php ENDPATH**/ ?>