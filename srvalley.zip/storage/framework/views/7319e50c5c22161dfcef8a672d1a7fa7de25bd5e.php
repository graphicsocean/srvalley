<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>SR valley | <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('ui/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <!--Default CSS-->
    <link href="<?php echo e(asset('ui/css/default.css')); ?>" rel="stylesheet" type="text/css">
    <!--Custom CSS-->
    <link href="<?php echo e(asset('ui/css/style.css')); ?>" rel="stylesheet" type="text/css">
    <!--Plugin CSS-->
    <link href="<?php echo e(asset('ui/css/plugin.css')); ?>" rel="stylesheet" type="text/css">
    <!--Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div id="status"></div>
    </div>
    <!-- Preloader Ends -->
    <?php
        $banquets = App\Models\Banquet::where('status', 1)->get();
    ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.header',['navigation'=>$banquets])->html();
} elseif ($_instance->childHasBeenRendered('BZEYpER')) {
    $componentId = $_instance->getRenderedChildComponentId('BZEYpER');
    $componentTag = $_instance->getRenderedChildComponentTagName('BZEYpER');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BZEYpER');
} else {
    $response = \Livewire\Livewire::mount('frontend.header',['navigation'=>$banquets]);
    $html = $response->html();
    $_instance->logRenderedChild('BZEYpER', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.footer')->html();
} elseif ($_instance->childHasBeenRendered('4VwukJV')) {
    $componentId = $_instance->getRenderedChildComponentId('4VwukJV');
    $componentTag = $_instance->getRenderedChildComponentTagName('4VwukJV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4VwukJV');
} else {
    $response = \Livewire\Livewire::mount('frontend.footer');
    $html = $response->html();
    $_instance->logRenderedChild('4VwukJV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


    <!-- Back to top start -->
    <div id="back-to-top">
        <a href="#"></a>
    </div>
    <!-- Back to top ends -->
    <!-- *Scripts* -->
    <script src="<?php echo e(asset('ui/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/plugin.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/custom-nav.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/custom-swiper1.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/custom-singledate.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH C:\server\htdocs\srvalley\resources\views/frontend/app.blade.php ENDPATH**/ ?>