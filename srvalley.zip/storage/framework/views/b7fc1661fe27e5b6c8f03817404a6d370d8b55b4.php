<?php
    $amenities = App\Models\Amenitie::where('status', 1)->get();
?>

<section class="rooms">
    <div class="container">
        <div class="section-title">
            <h2>Explore our <span>Amenities</span></h2>
            <p>Our Amazing Amenities are:</p>
        </div>
        <div class="room-outer">
            <div class="row">
                <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 mar-bottom-30">
                        <div class="room-item">
                            <div class="room-image">
                                <img src="<?php echo e(asset('ui/images/' . $item->image)); ?>" alt="image">
                            </div>
                            <div class="room-content">
                                <div class="room-title">
                                    <h4><?php echo e($item->name); ?></h4>
                                </div>
                                <p><?php echo e($item->desc); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>


<?php /**PATH C:\server\htdocs\srvalley\resources\views/livewire/frontend/amenities.blade.php ENDPATH**/ ?>