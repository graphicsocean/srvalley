<div class="header_menu affix-top">
    <nav class="navbar navbar-default">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <a class="navbar-brand" href="index.html">
                    <img alt="Image" src="<?php echo e(asset('ui/images/logo-black.png')); ?>" class="logo-black">
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav" id="responsive-menu">
                    
                    <li class="dropdown"><a href="<?php echo e(route('about')); ?>">About</a></li>
                    <li class="dropdown"><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                    <li class="dropdown submenu">
                        <a href="cart.html" class="mt_cart"><i class="fa fa-shopping-cart"></i><span class="number-cart">1</span></a>
                    </li>

                </ul>
                <div class="nav-btn">
                    <a href="#" class="btn btn-orange">Book Now</a>
                </div>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
        <div id="slicknav-mobile"></div>
    </nav>
</div>

<div>
    
</div>
<?php /**PATH C:\server\htdocs\srvalley\resources\views/livewire/frontend/navbar.blade.php ENDPATH**/ ?>