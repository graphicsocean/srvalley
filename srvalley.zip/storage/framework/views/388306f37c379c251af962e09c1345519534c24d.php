<a href="#" class="dashboard-responsive-nav-trigger"><i class="fa fa-reorder"></i> Dashboard Navigation</a>

<div class="dashboard-sticky-nav">
    <div class="content-left pull-left">
        <a href="<?php echo e(url('admin/dashboard')); ?>"><img src="<?php echo e(asset('ui/images/white-logo.png')); ?>" alt="logo"></a>
    </div>
    <div class="content-right pull-right">
        <div class="dropdown">
            <a class="dropdown-toggle">
                <div class="profile-sec">
                    <div class="dash-image">
                        <img src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="<?php echo e(Auth::user()->name); ?>" alt="">
                    </div>
                    <div class="dash-content">
                        <h4><?php echo e(Auth::user()->name); ?></h4>
                        <span>Manager</span>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>
<?php /**PATH C:\server\htdocs\srvalley\resources\views/admin/includes/header.blade.php ENDPATH**/ ?>