<?php $__env->startSection('title', 'Banquet ' . $banquet->name); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.breadcrumb', ['title' => 'banquet '.$banquet->slug])->html();
} elseif ($_instance->childHasBeenRendered('nCbYGYU')) {
    $componentId = $_instance->getRenderedChildComponentId('nCbYGYU');
    $componentTag = $_instance->getRenderedChildComponentTagName('nCbYGYU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nCbYGYU');
} else {
    $response = \Livewire\Livewire::mount('frontend.breadcrumb', ['title' => 'banquet '.$banquet->slug]);
    $html = $response->html();
    $_instance->logRenderedChild('nCbYGYU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- details starts-->
    <section class="details">
        <div class="container">
            <div class="detail-slider">
                <div class="slider-1 slider-for">
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="detail-slider-item">
                            <img src="<?php echo e(asset('ui/images/detail-slider/'. $banquet->slider->path)); ?>" alt="<?php echo e($banquet->name); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="slider-1 slider-nav">
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="detail-slider-item">
                            <img src="<?php echo e(asset('ui/images/detail-slider/'. $banquet->slider->path)); ?>" alt="<?php echo e($banquet->name); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="detail-content">
                <div class="detail-title">
                    <div class="title-left">
                        <h3><?php echo e($banquet->name); ?></h3>
                        <div class="rating">
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                        </div>
                    </div>
                    <div class="title-right pull-right">
                        <ul>
                            <li class="facebook"><i class="fab fa-facebook"></i></li>
                            <li class="twitter"><i class="fab fa-twitter"></i></li>
                            <li class="linkedin"><i class="fab fa-linkedin"></i></li>
                            <li class="pinterest"><i class="fab fa-pinterest"></i></li>
                        </ul>
                        <div class="title-price">
                            <h3>₹ <?php echo e($banquet->price); ?><span>/Night</span></h3>
                        </div>
                    </div>
                </div>
                <div class="detail-overview">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="overview-outer">
                                <div class="overview-content mar-bottom-30">
                                    <h4>Overview</h4>
                                    <p><?php echo html_entity_decode($banquet->overview); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="overwiew-map">
                                <div id="map" style="height: 357px; width: 100%;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- details Ends-->

    <!-- amenities starts -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.amenities')->html();
} elseif ($_instance->childHasBeenRendered('tBLNE6B')) {
    $componentId = $_instance->getRenderedChildComponentId('tBLNE6B');
    $componentTag = $_instance->getRenderedChildComponentTagName('tBLNE6B');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tBLNE6B');
} else {
    $response = \Livewire\Livewire::mount('frontend.amenities');
    $html = $response->html();
    $_instance->logRenderedChild('tBLNE6B', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.services')->html();
} elseif ($_instance->childHasBeenRendered('X7LQqwa')) {
    $componentId = $_instance->getRenderedChildComponentId('X7LQqwa');
    $componentTag = $_instance->getRenderedChildComponentTagName('X7LQqwa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('X7LQqwa');
} else {
    $response = \Livewire\Livewire::mount('frontend.services');
    $html = $response->html();
    $_instance->logRenderedChild('X7LQqwa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- amenities Ends -->

    <!-- detail features starts-->
    
    <!-- detail features Ends-->

    <!-- related rooms starts -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.explore-banquate',['banquets'=>$banquets])->html();
} elseif ($_instance->childHasBeenRendered('aLXHMzx')) {
    $componentId = $_instance->getRenderedChildComponentId('aLXHMzx');
    $componentTag = $_instance->getRenderedChildComponentTagName('aLXHMzx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('aLXHMzx');
} else {
    $response = \Livewire\Livewire::mount('frontend.explore-banquate',['banquets'=>$banquets]);
    $html = $response->html();
    $_instance->logRenderedChild('aLXHMzx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- related rooms Ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\server\htdocs\srvalley\resources\views/frontend/banquetmodel.blade.php ENDPATH**/ ?>