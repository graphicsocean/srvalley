<div>
     Happiness is not something readymade. It comes from your own actions. - Dalai Lama
</div>
<?php /**PATH C:\server\htdocs\srvalley\resources\views/components/alert.blade.php ENDPATH**/ ?>