<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('header')->html();
} elseif ($_instance->childHasBeenRendered('tgl0Igu')) {
    $componentId = $_instance->getRenderedChildComponentId('tgl0Igu');
    $componentTag = $_instance->getRenderedChildComponentTagName('tgl0Igu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tgl0Igu');
} else {
    $response = \Livewire\Livewire::mount('header');
    $html = $response->html();
    $_instance->logRenderedChild('tgl0Igu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <h1>App</h1>
    <?php echo e($slot); ?>

</body>
</html>

<div>
    <!-- Simplicity is the consequence of refined emotions. - Jean D'Alembert -->
</div>
<?php /**PATH C:\server\htdocs\srvalley\resources\views/components/frontend/app.blade.php ENDPATH**/ ?>