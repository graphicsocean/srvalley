<?php $__env->startSection('content'); ?>
<div class="dashboard-content">
    <div class="row">
        <div class="col-lg-12 col-sm-12">
            <div class="dashboard-list-box dash-list margin-top-0">
                <a class="button preview" href="<?php echo e(route('banquet.create')); ?>">Add</a>
                <div class="row">
                    <?php $__currentLoopData = $banquet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4"><!-- list start -->
                            <div class="list-box-listing">
                                <div class="list-box-listing-img">
                                    <a href="#"><img src="<?php echo e(asset('ui/images/'.$item->thumbnail)); ?>" alt=""></a>
                                </div>
                                <div class="list-box-listing-content">
                                    <div class="inner">
                                        <a href="#"><h3><?php echo e($item->name); ?></h3></a>
                                        <p></p>
                                    </div>
                                    <a href="<?php echo e(url('admin/banquet/'.$item->id.'/edit')); ?>" class="button gray"><i class="sl sl-icon-pencil"></i> Edit</a>
                                    <p>Status: <?php if($item->status === 1): ?>
                                        Active
                                        <?php else: ?>
                                        Inactive
                                    <?php endif; ?></p>
                                </div>

                            </div>
                        </div><!-- list end -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\server\htdocs\srvalley\resources\views/admin/banquet/index.blade.php ENDPATH**/ ?>