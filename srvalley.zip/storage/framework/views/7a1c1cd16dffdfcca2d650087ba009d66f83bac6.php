<?php $__env->startSection('title', ' About us'); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.breadcrumb', ['title' => 'about us'])->html();
} elseif ($_instance->childHasBeenRendered('Y3ih3Si')) {
    $componentId = $_instance->getRenderedChildComponentId('Y3ih3Si');
    $componentTag = $_instance->getRenderedChildComponentTagName('Y3ih3Si');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Y3ih3Si');
} else {
    $response = \Livewire\Livewire::mount('frontend.breadcrumb', ['title' => 'about us']);
    $html = $response->html();
    $_instance->logRenderedChild('Y3ih3Si', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- about starts -->
    <section class="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="about-para mar-top-50">
                        <h3>About SR valley</h3>
                        <h4>Pick a Banquet that best suits your taste and budget</h4>
                        <p style="text-align: justify">SR Valley love to build for you unique and unforgettable memories of your wedding and event
                            management. To organize your big day, you have to entrust the realization of your SR valley
                            desire to professional in wedding event planning. Since 2011, we are among the best wedding and
                            event management. We love to create unique and bespoke weddings corporate event management
                            company since 2011.
                        </p>
                        <p style="text-align: justify">Mr GAGAN PRADHAN owner of SR valley was Inaugurated on big date : 2nd March 2018.
                            Mr pradhan started SR valley was desire to professional inspired to start a wedding and event
                            planning with amazing and best services of venue, decoration, light, sound and catering for
                            wedding events.
                        </p>
                        <p style="text-align: justify">Mr. Pradhan specially known for his social work to help poor people in terms of financial issues
                            to let them use marriage venues with zero rental charges. For wedding events SR valley has 4
                            wedding venues such as: Gagansha Wedding, Lotus, Butterfly and orchid. Venue's total area is
                            around more than 18000 sq. ft and 1 lakh 35 thousand sq. ft with secure safety parking space</p>
                        <h5 class="text-capitalize">Here are our Banquets for wedding events and
                            planning:
                        </h5>
                        <div class="about-para-list mar-top-20">
                            <div class="row">
                                <div class="col-md-4 col-sm-4 col-xs-4">
                                    <div class="about-icon"><i class="fa fa-chess-queen"></i> Banquet Butterfly</div>
                                </div>
                                <div class="col-md-4 col-sm-4 col-xs-4">
                                    <div class="about-icon"><i class="fa fa-chess-queen"></i> Banquet Lotus</div>
                                </div>
                                <div class="col-md-4 col-sm-4 col-xs-4">
                                    <div class="about-icon"><i class="fa fa-chess-queen"></i> Banquet Orchid</div>
                                </div>
                                 <div class="col-md-4 col-sm-4 col-xs-4">
                                    <div class="about-icon"><i class="fa fa-chess-queen"></i> Gagansha Weddings</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="about-us-image mar-top-50">
                        <img src="<?php echo e(asset('ui/images/gallery/gallery1.jpg')); ?>" alt="image">
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- about Ends -->

    <!-- about Faq Starts -->
    
    <!-- about Faq Ends -->

    <!-- about video starts -->
    <section class="video-box">
        <div class="container">
            <div class="section-title">
                <h3 class="white mar-0">Take a Tour</h3>
                <div class="call-button">
                    <button type="button" class="play-btn " onclick="vertualTour();"><i
                            class="fa fa-play"></i></button>
                </div>
                <div class="video-figure"></div>
                <h4 class="white mar-0">0f our wonderful banquet's</h4>
            </div>
        </div>
    </section>
    <!-- about video Ends -->

    <!-- Reviews Starts -->
    <section class="reviews">
        <div class="container">
            <div class="section-title title-white">
                <h2>Explore <span>Reviews</span></h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ex neque, sodales accumsan sapien et,
                    auctor vulputate quam donec vitae consectetur turpis</p>
            </div>
            <div class="review-slider">
                <div class="slider-item">
                    <div class="slider-image">
                        <img src="<?php echo e(asset('ui/images/review1.jpg')); ?>" alt="image">
                    </div>
                    <div class="slider-content">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod tortor vitae nisi pharetra
                            egestas. Sed egestas sapien libero.</p>
                        <h4>Micheal Clordy</h4>
                        <span>Germany</span>
                    </div>
                    <div class="slider-quote">
                        <img src="<?php echo e(asset('ui/images/icons/quote.png')); ?>" alt="Image">
                    </div>
                </div>
                <div class="slider-item">
                    <div class="slider-image">
                        <img src="<?php echo e(asset('ui/images/review2.jpg')); ?>" alt="image">
                    </div>
                    <div class="slider-content">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod tortor vitae nisi pharetra
                            egestas. Sed egestas sapien libero.</p>
                        <h4>Ketty Perry</h4>
                        <span>Australia</span>
                    </div>
                    <div class="slider-quote">
                        <img src="<?php echo e(asset('ui/images/icons/quote.png')); ?>" alt="Image">
                    </div>
                </div>
                <div class="slider-item">
                    <div class="slider-image">
                        <img src="<?php echo e(asset('ui/images/review1.jpg')); ?>" alt="image">
                    </div>
                    <div class="slider-content">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod tortor vitae nisi pharetra
                            egestas. Sed egestas sapien libero.</p>
                        <h4>Micheal Clordy</h4>
                        <span>Germany</span>
                    </div>
                    <div class="slider-quote">
                        <img src="<?php echo e(asset('ui/images/icons/quote.png')); ?>" alt="Image">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Reviews Ends -->

    <!-- Services Starts -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.services')->html();
} elseif ($_instance->childHasBeenRendered('llZViCN')) {
    $componentId = $_instance->getRenderedChildComponentId('llZViCN');
    $componentTag = $_instance->getRenderedChildComponentTagName('llZViCN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('llZViCN');
} else {
    $response = \Livewire\Livewire::mount('frontend.services');
    $html = $response->html();
    $_instance->logRenderedChild('llZViCN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- Services Ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\server\htdocs\srvalley\resources\views/frontend/about.blade.php ENDPATH**/ ?>