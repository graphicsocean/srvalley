<?php echo e($sliders); ?></td>


<?php /**PATH C:\server\htdocs\srvalley\resources\views/test.blade.php ENDPATH**/ ?>