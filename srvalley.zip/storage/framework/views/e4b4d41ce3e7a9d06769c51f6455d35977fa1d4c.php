<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Home Default | Hotux</title>
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
        <!-- Bootstrap core CSS -->
        <link href="<?php echo e(asset('ui/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
        <!--Default CSS-->
        <link href="<?php echo e(asset('ui/css/default.css')); ?>" rel="stylesheet" type="text/css">
        <!--Custom CSS-->
        <link href="<?php echo e(asset('ui/css/style.css')); ?>" rel="stylesheet" type="text/css">
        <!--Plugin CSS-->
        <link href="<?php echo e(asset('ui/css/plugin.css')); ?>" rel="stylesheet" type="text/css">
        <!--Font Awesome-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
<body>
    <!-- Preloader -->
    <div id="preloader">
        <div id="status"></div>
    </div>
    <!-- Preloader Ends -->
    <h1>Layout</h1>
        <?php echo e($slot); ?>

    <!-- *Scripts* -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="<?php echo e(asset('ui/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/plugin.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/main.js')); ?>"></script>
    <script src="js/custom-nav.js"></script>
    <script src="<?php echo e(asset('ui/js/custom-swiper1.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/custom-singledate.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH C:\server\htdocs\srvalley\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>