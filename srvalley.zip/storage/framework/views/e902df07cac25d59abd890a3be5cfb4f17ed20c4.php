<?php $__env->startSection('title', 'Our Gallery'); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.breadcrumb', ['title' => 'our gallery'])->html();
} elseif ($_instance->childHasBeenRendered('cQzypPb')) {
    $componentId = $_instance->getRenderedChildComponentId('cQzypPb');
    $componentTag = $_instance->getRenderedChildComponentTagName('cQzypPb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cQzypPb');
} else {
    $response = \Livewire\Livewire::mount('frontend.breadcrumb', ['title' => 'our gallery']);
    $html = $response->html();
    $_instance->logRenderedChild('cQzypPb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <section class="content gallery" data-ref="container-1">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt_filter">
                        <ul class="list-inline text-center filter">
                            
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row mar-top-50">
                <div class="isotopeContainer">
                   <?php for($i=1;$i <=12;$i++): ?>
                        <div class="isotopeSelector butterfly col-lg-4 col-md-6">
                            <div class="gallery-item">
                                <div class="gallery-image">
                                    <img src="<?php echo e(asset('ui/images/gallery/'.$i.'.webp')); ?>" alt="image">
                                </div>
                                <div class="gallery-content">
                                    <ul>
                                        <li><a href="<?php echo e(asset('ui/images/gallery/'.$i.'.webp')); ?>" data-lightbox="gallery"
                                                data-title="Title"><i class="fa fa-eye"></i></a></li>
                                        <li><a href="#"><i class="fa fa-share"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                   <?php endfor; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\server\htdocs\srvalley\resources\views/frontend/gallery.blade.php ENDPATH**/ ?>