<?php
$settings = App\Models\Setting::first();
?>

<header class="main_header_area headerstyle-2">
    <div class="header-content">
        <div class="container">
            <div class="links links-left">
                <ul>
                    <li><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i> <?php echo e($settings->email); ?></a></li>
                    <li><a href="tel:0<?php echo e($settings->phone); ?>"><i class="fa fa-phone" aria-hidden="true"></i>
                            +91-<?php echo e($settings->phone); ?></a>
                    </li>
                </ul>
            </div>
            <div class="links links-right pull-right">
                <li>
                    <ul class="social-links">
                        <li><a href="<?php echo e($settings->fb_link); ?>"><i class="fab fa-facebook" aria-hidden="true"></i></a>
                        </li>
                        <li><a href="<?php echo e($settings->insta_link); ?>"><i class="fab fa-instagram"
                                    aria-hidden="true"></i></a></li>
                        <li><a href="<?php echo e($settings->gbiz_link); ?>"><i class="fa fa-map" aria-hidden="true"></i></a></li>
                    </ul>
                </li>
            </div>
        </div>
    </div>
    <!-- Navigation Bar -->
    <div class="header_menu affix-top">
        <nav class="navbar navbar-default">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img alt="Image" src="<?php echo e(asset('ui/images/logo.png')); ?>" class="logo-black">
                    </a>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav" id="responsive-menu">
                        <li class=" submenu dropdown active"><a href="<?php echo e(route('about')); ?>">About</a></li>
                        <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                        <li><a href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
                        <li class="submenu dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                aria-haspopup="true" aria-expanded="false">Banquet's<i class="fa fa-angle-down"
                                    aria-hidden="true"></i></a>
                            
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(url('banquet/' . $item->slug)); ?>"><?php echo e($item->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url('banquet/gagansha-wedding')); ?>">Gagansha Wedding</a></li>
                            </ul>
                        </li>
                    </ul>
                    <div class="nav-btn">
                        <a href="tel:0<?php echo e($settings->phone); ?>" class="btn btn-orange"> Book Now <i
                                class="fas fa-angle-double-right"></i></a>
                    </div>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
            <div id="slicknav-mobile"></div>
        </nav>
    </div>
    <!-- Navigation Bar Ends -->
</header>

<div>
    
</div>
<?php /**PATH C:\server\htdocs\srvalley\resources\views/livewire/frontend/header.blade.php ENDPATH**/ ?>