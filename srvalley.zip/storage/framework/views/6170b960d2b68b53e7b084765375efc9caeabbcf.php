<div class="copyrights">
    <p><?php echo e(date('Y')); ?> <i class="fa fa-copyright" aria-hidden="true"></i> SRvalley by <a href="#"
            target="_blank">TheBlockbusters</a></p>
</div>
<?php /**PATH C:\server\htdocs\srvalley\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>