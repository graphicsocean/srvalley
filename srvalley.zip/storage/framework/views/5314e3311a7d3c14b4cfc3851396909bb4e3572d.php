<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Home Default | Hotux</title>
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
        <!-- Bootstrap core CSS -->
        <link href="<?php echo e(asset('ui/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
        <!--Default CSS-->
        <link href="<?php echo e(asset('ui/css/default.css')); ?>" rel="stylesheet" type="text/css">
        <!--Custom CSS-->
        <link href="<?php echo e(asset('ui/css/style.css')); ?>" rel="stylesheet" type="text/css">
        <!--Plugin CSS-->
        <link href="<?php echo e(asset('ui/css/plugin.css')); ?>" rel="stylesheet" type="text/css">
        <!--Font Awesome-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
<body>
    <!-- Preloader -->
    <div id="preloader">
        <div id="status"></div>
    </div>
    <!-- Preloader Ends -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.header')->html();
} elseif ($_instance->childHasBeenRendered('qRvfFmU')) {
    $componentId = $_instance->getRenderedChildComponentId('qRvfFmU');
    $componentTag = $_instance->getRenderedChildComponentTagName('qRvfFmU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qRvfFmU');
} else {
    $response = \Livewire\Livewire::mount('frontend.header');
    $html = $response->html();
    $_instance->logRenderedChild('qRvfFmU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php echo $__env->yieldContent('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.footer')->html();
} elseif ($_instance->childHasBeenRendered('EAd9lZM')) {
    $componentId = $_instance->getRenderedChildComponentId('EAd9lZM');
    $componentTag = $_instance->getRenderedChildComponentTagName('EAd9lZM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EAd9lZM');
} else {
    $response = \Livewire\Livewire::mount('frontend.footer');
    $html = $response->html();
    $_instance->logRenderedChild('EAd9lZM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


    <!-- Back to top start -->
    <div id="back-to-top">
        <a href="#"></a>
    </div>
    <!-- Back to top ends -->
    <!-- *Scripts* -->
    <script src="<?php echo e(asset('ui/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/plugin.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/main.js')); ?>"></script>
    <script src="js/custom-nav.js"></script>
    <script src="<?php echo e(asset('ui/js/custom-swiper1.js')); ?>"></script>
    <script src="<?php echo e(asset('ui/js/custom-singledate.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH C:\server\htdocs\srvalley\resources\views/frontend/layout/app.blade.php ENDPATH**/ ?>