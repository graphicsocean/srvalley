
<?php
$settings = App\Models\Setting::first();
?>
<div>
    <section class="newsletter">
        <div class="container">
            <div class="section-title title-white">
                <h2>Subscribe to our <span>Newsletter</span></h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ex neque, sodales accumsan sapien et,
                    auctor vulputate quam donec vitae consectetur turpis</p>
            </div>
            <div class="newsletter-form">
                <form>
                    <input type="email" placeholder="Enter your email">
                    <a href="#" class="btn btn-orange"><i class="fa fa-envelope" aria-hidden="true"></i> SEND</a>
                </form>
            </div>
        </div>
    </section>
    
    <footer>
        <div class="footer-top pad-bottom-20">
            <div class="container">
                <div class="footer-logo text-center">
                    <img src="<?php echo e(asset('ui/images/logo.png')); ?>" alt="Image">
                </div>
                <div class="footer-content">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 mar-bottom-30">
                            <div class="footer-about">
                                <h4>Company Info</h4>
                                <p><?php echo e($settings->info); ?></p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 mar-bottom-30">
                            <div class="quick-links">
                                <h4>Quick Links</h4>
                                <ul>
                                    <li><a href="#">Home</a></li>
                                    <li><a href="<?php echo e(url('about')); ?>">About</a></li>
                                    <li><a href="#banqets">Banquet's</a></li>
                                    <li><a href="#">Testimonials</a></li>
                                    <li><a href="<?php echo e(url('/blog')); ?>">Blog</a></li>
                                    <li><a href="<?php echo e(url('gallery')); ?>">Gallery</a></li>
                                    <li><a href="#">Services</a></li>
                                    <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 mar-bottom-30">
                            <div class="Rooms">
                                <h4>Banquet's</h4>
                                <ul>
                                    <li><a href="#">Single Rooms</a></li>
                                    <li><a href="#">Double Rooms</a></li>
                                    <li><a href="#">Studio Rooms</a></li>
                                    <li><a href="#">Kingsize Rooms</a></li>
                                    <li><a href="#">Presidentsuite Rooms</a></li>
                                    <li><a href="#">Luxury Kings Rooms</a></li>
                                    <li><a href="#">Connecting Rooms</a></li>
                                    <li><a href="#">Murphy Rooms</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 mar-bottom-30">
                            <div class="footer-contact">
                                <h4>Contact info</h4>
                                <ul>
                                    <li>Tel: +91-<?php echo e($settings->phone); ?></li>
                                    <li>Email: <?php echo e($settings->email); ?></li>
                                    <li><?php echo e($settings->address); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-copyright pad-bottom-20">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 mar-bottom-10">
                        <div class="copyright-content">
                            <p>Copyright <?php echo e(date('Y')); ?> <?php echo e($settings->name); ?> All Rights Reserved. Made with
                                <span>♥</span> by <a href="#">TheBlockbuster</a></p>
                        </div>
                    </div>
                    <div class="col-lg-4 mar-bottom-10">
                        <div class="tripadvisor-logo text-center">
                            <img src="<?php echo e(asset('ui/images/white-logo.png')); ?>" alt="SRvalley Logo">
                        </div>
                    </div>
                    <div class="col-lg-4 mar-bottom-10">
                        <div class="copyright-links mar-bottom-20">
                            <ul>
                                <li><a href="<?php echo e($settings->fb_link); ?>"><i class="fab fa-facebook"
                                            aria-hidden="true"></i></a></li>
                                <li><a href="<?php echo e($settings->insta_link); ?>"><i class="fab fa-instagram"
                                            aria-hidden="true"></i></a></li>
                                <li><a href="<?php echo e($settings->gbiz_link); ?>"><i class="fa fa-map"
                                            aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    
</div>
<?php /**PATH C:\server\htdocs\srvalley\resources\views/livewire/frontend/footer.blade.php ENDPATH**/ ?>