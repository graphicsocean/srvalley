<div class="dashboard-nav">
    <div class="dashboard-nav-inner">
        <ul>
            <li class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard')); ?>"><i class="sl sl-icon-settings"></i> Dashboard</a></li>
            <li class="<?php echo e(request()->routeIs('banners.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('banners.index')); ?>"><i class="sl sl-icon-picture"></i>Home Banner</a></li>
            <li class="<?php echo e(request()->routeIs('banquet.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('banquet.index')); ?>"><i class="sl sl-icon-list"></i>Banquets</a></li>
            <li class="<?php echo e(request()->routeIs('service.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('service.index')); ?>"><i class="sl sl-icon-book-open"></i>Service</a></li>
            <li class="<?php echo e(request()->routeIs('amenitie.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('amenitie.index')); ?>"><i class="sl sl-icon-book-open"></i>Amenities</a></li>
            <li class="<?php echo e(request()->routeIs('setting.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('setting.index')); ?>"><i class="sl sl-icon-settings"></i>Settings</a></li>
            <li><a href="#"><i class="sl sl-icon-power"></i> Logout</a></li>
        </ul>
    </div>
</div>
<?php /**PATH C:\server\htdocs\srvalley\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>