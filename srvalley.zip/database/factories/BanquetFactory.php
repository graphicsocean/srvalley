<?php

namespace Database\Factories;

use App\Models\Banquet;
use Illuminate\Database\Eloquent\Factories\Factory;

class BanquetFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Banquet::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
